# Phoenix Wright: Ace Attorney Trilogy — PS Vita Converter (build25)

This tool builds a complete PS Vita `Media` folder from your own clean Steam PC copy of *Phoenix Wright: Ace Attorney Trilogy* (and optionally converts the *Failing Forward* Russian translation or another community PC translation).

## What runs locally on your PC

- **Audio (478 banks):** decoded from your PC copy and re-encoded to PS Vita HEVAG/FSB5.
- **Graphics, sprites, atlases, 3D evidence models & script data (5,944+ bundles):** converted locally from your PC copy to PSP2 format.
- **Compatible scenario/data files (1,390 files):** copied directly from your PC copy and SHA-256 verified.
- **Video streams (5 movies):** `film00`, `film03`, `videonoise`, `film01_confront`, and `film02_confront` are converted locally into `.frames.bin` streams for the Vita player.
- **Core & IL2CPP patch (`build24-core.pwaatpatch`):** reconstructs the Vita IL2CPP module and Unity core files via `xdelta3` against your verified Steam PC files, and installs the custom Vita button icons and native trophy plugin.

## Requirements

- Windows 10/11 (64-bit)
- A clean, legitimately owned Steam PC copy of *Phoenix Wright: Ace Attorney Trilogy* (`PWAAT_Data`)
- At least **4 GB** of free disk space on the output drive and Windows `%TEMP%` drive
- Keep `PWAATVitaConverter.exe`, `build24-core.pwaatpatch`, and `ffmpeg.exe` (download from https://github.com/FFmpeg/FFmpeg or https://www.gyan.dev/ffmpeg/builds/) in the same folder (or have `ffmpeg` in PATH)

## How to use

1. Run `PWAATVitaConverter.exe`.
2. Choose a mode:
   - **1** — Convert the Steam PC version to PS Vita `Media`
   - **2** — Add the *Failing Forward* Russian translation to an existing Vita `Media` folder
   - **3** — Convert the Steam PC version **and** include the *Failing Forward* Russian translation
   - **4** — Install another community PC translation (custom language slot, no voice-over; replaces Russian, supports custom `.ttf`/`.otf` font and custom menu label)
3. Select the requested folders and an output folder (you can pick an empty folder or your existing `OBJECTION` folder directly — files outside `Media` such as `eboot.bin` and `sce_sys` are left untouched).
4. Wait for **`Complete build24 Media created`**.
5. Install the port `.vpk` on your PS Vita, then copy the generated `Media` folder to:
   ```text
   ux0:app/OBJECTION/Media
   ```

If conversion is interrupted, run the tool again with the same folders — completed files are verified and resumed automatically.

## Command-line usage

```powershell
.\PWAATVitaConverter.exe --mode original --steam "D:\Steam\PWAAT_Data" --output "D:\VitaOutput"
.\PWAATVitaConverter.exe --mode russian --russian "D:\Failing Forward\PWAAT_Data" --installed "D:\VitaOutput\Media" --output "D:\VitaRussianOverlay"
.\PWAATVitaConverter.exe --mode both --steam "D:\Steam\PWAAT_Data" --russian "D:\Failing Forward\PWAAT_Data" --output "D:\VitaOutput"
.\PWAATVitaConverter.exe --mode custom --installed "D:\VitaOutput\Media" --steam "D:\Steam\PWAAT_Data" --translation "D:\MyMod\PWAAT_Data" --label "Tieng Viet" --font "C:\Windows\Fonts\arial.ttf"
```

Use `--patch` and `--ffmpeg` to specify custom paths if needed.
