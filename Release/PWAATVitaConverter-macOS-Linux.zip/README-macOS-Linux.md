# Phoenix Wright: Ace Attorney Trilogy — PS Vita Converter (macOS / Linux)

## Option A: Full Steam conversion (Modes 1–4) via Wine (Recommended)
The PS Vita audio re-encoder (`HevagEncoder.exe`) and `vgmstream-cli.exe` are Windows binaries.
To run a full conversion from Steam PC files (Modes 1 and 3) on macOS or Linux, download `PWAATVitaConverter-Windows.zip` and run it with Wine / CrossOver / Whisky:

```bash
wine PWAATVitaConverter.exe --mode original --steam "/path/to/PWAAT_Data" --output "/path/to/VitaOutput"
```

## Option B: Native Python 3 on macOS / Linux (Modes 2 and 4)
Adding the **Failing Forward Russian translation** (Mode 2) or **any other community PC translation** (Mode 4) to an existing Vita `Media` folder runs 100% natively in Python 3 on macOS and Linux (no Wine required):

```bash
python3 -m pip install UnityPy pillow pycryptodome
chmod +x run.sh

# Mode 2: Failing Forward Russian translation + fan Russian voice pack
./run.sh --mode russian --installed "/path/to/OBJECTION/Media" --russian "/path/to/FailingForward/PWAAT_Data" --output "/path/to/Output"

# Mode 4: Any community PC translation (auto-detects patch font)
./run.sh --mode custom --installed "/path/to/OBJECTION/Media" --steam "/path/to/PWAAT_Data" --translation "/path/to/ModFolder" --label "Tieng Viet"
```
