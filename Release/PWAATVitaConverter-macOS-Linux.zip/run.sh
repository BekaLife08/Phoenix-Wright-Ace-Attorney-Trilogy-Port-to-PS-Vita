#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
exec python3 "$DIR/Tools/Release/build24_converter.py" --patch "$DIR/build24-core.pwaatpatch" "$@"
